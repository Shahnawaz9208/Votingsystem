<?php @session_start(); ob_start(); ?>
<!DOCTYPE html>
<html>

<head>
<title>eVoting</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../font-awsome/css/font-awesome.min.css">
<link rel="stylesheet" href="../css/stylee.css">

<script src="../js/jquery.min.js"></script>
<script src="../js/main.js"></script>
<script src="../js/bootstrap.min.js"></script>
</head>

<body style="background-image: linear-gradient(to bottom right, #f04040, #f05f40);"> 
    <main>
        <?php include("db.php");?>

        <nav class="navbar navbar-expand-lg navbar-light bg-light" id="nav">
                <div class="container-fluid">

            <div class="">
                 <h1 class="site_name">
                    <a href="logout.php">e<span>V</span>oting</a>
                 </h1>
            </div>

                    <nav>
                        <ul class="nav navbar-nav ml-auto">

                    <?php if(!isset($_SESSION['enroll_number'])){?>
                              <li class="nav-item">
                                <a class="nav-link" id="link" href="logout.php">Login</a>
                              </li>
                    <?php } if(isset($_SESSION['enroll_number'])){?>
                              <li class="nav-item">
                                <a class="nav-link" id="link" href="logout.php">Logout</a>
                              </li>
                    <?php } ?>

                        </ul>
                    </nav>
                </div>
        </nav>

   <div class="container">
    <div class="row" style="padding: 11% 6% 0 6%;">
        <div class="col-md-1"> </div>
        <div class="col-md-10"> <h2 style="color: white; font-family:  Arial";>VOTING SESSION COMPELETED</h2><hr style="background-color: white; height: 1px;">
    <div class="message_box" style="font-size:18px"></div>
    
    <h2></h2>
<?php

    $enroll_id = $_SESSION['enroll_number'];
    $sql = "SELECT * FROM tb_vote WHERE voter = '$enroll_id' ORDER BY position DESC";
    $query = mysqli_query($con, $sql);
    while($row_done = mysqli_fetch_array($query)){
    $voter = $row_done['voter'];
    $position = $row_done['position'];
    $candidate = $row_done['candidate'];
        
            echo '<h5 style="color:#eee">'.$position.' --> '.$candidate.'</h5><br>';
        
     }
  
?>
<button style="border-radius: 60px; padding: 15px 30px;" type="submit" class="btn btn-light"><a href="logout.php" style="text-decoration:none">Logout</a></button>

  <hr style="background-color: white;">
        </div>

    
</div>
</div>
</main>
<div id="hideme">
</body>
<?php include ('footer.html'); ?>

</html>
